int v[5];
max (int x, int y) {
    if (x > y) {
        return x;
    }
    return y;
}
main () {
    v[0] = 3;
    v[1] = 7;
    printf("%s", max(v[0], v[1]));
}