main() {
    puts("Hola mundo");
}