int b[5];
main () {
    int v[3];
    printf("%s", b);
}