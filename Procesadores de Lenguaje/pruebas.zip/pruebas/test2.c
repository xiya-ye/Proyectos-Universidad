int a;
main() {
    @ (a + 1);
}