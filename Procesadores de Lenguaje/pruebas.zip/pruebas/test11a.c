funcion () {
    puts("print desde funcion");
}

main () {    
    funcion();
    puts("print desde main");
}