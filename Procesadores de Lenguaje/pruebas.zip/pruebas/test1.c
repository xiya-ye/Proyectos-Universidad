int a;
int a=3, b=1, c;