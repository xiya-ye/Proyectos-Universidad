int g = 10;
suma (int x, int y) {
    printf("ignorado", x + y + g);
}

main () {    
    suma (3, g+1);
}