int a;
main() {
    a = 10;
    printf("Test lógico: ", a > 5 && !(a == 20) || a % 2 != 0);
}