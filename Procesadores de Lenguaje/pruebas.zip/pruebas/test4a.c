int a;
main() {
    a = 5;
    printf("El valor es: %d", a);
    printf("Unidad: %s", "metros");
}