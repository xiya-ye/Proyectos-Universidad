int a;
main() {
    a = 0;
    while(a<5) {
        printf("Ignorado", a);
        a = a + 1;
    }
}