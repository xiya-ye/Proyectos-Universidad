int a;

main() {
    int a = 4;
    int i = 0;
    
    puts("Inicio del FOR:");
    
    for (i = 0; i < 3; INC(i)) {
        a = a + 1;
        printf("Valor de a: ", a);
        puts("");
    }
}