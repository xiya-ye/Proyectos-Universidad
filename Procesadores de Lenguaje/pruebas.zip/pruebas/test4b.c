int edad;
main() {
    edad = 20;
    printf("Texto formato ignorado", "Tienes ", edad, " años y el doble es ", edad * 2);
}