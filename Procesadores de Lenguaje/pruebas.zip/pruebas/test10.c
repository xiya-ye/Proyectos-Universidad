int estado;
main() {
    int estado = 2;
    int valor = 0;

    switch (estado) {
        case 1:
            valor = 10;
            break;
        case 2:
            valor = 20;
            break;
        default:
            valor = -1;
            break;
    }
}