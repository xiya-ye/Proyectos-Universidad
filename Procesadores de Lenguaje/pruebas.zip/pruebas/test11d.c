square (int v) {
    return (v*v);
}
main () {
    square(7);
}