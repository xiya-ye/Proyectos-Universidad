int b[5];
main () {
    b[0] = 123;
    b[2+1] = b[0] + 1;
    printf("%s", b[0]);
    printf("%s", b[3]);
}