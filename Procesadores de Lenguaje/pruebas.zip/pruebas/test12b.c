int b[5];
main () {
    printf("%s", b[0]);
    printf("%s", b[2+1]);
}