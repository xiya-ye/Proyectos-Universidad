square (int v) {
    return (v*v);
}
fact (int n) {
    int f;
    if (n == 1) {
        f = 1;
    } else {
        f = n * fact(n-1);
    }
    return f;
}
abs_val (int x) {
    if (x < 0) {
        return -x;
    }
    return x;
}
main () {
    printf("%d\n", square(7));
    printf("%d\n", fact(7));
    printf("%d\n", abs_val(-5));
    printf("%d\n", abs_val(5));
}